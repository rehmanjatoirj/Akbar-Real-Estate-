
import React, { useState, useEffect } from 'react';
import { NAV_ITEMS, BUSINESS_INFO } from '../constants';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [hasApiKey, setHasApiKey] = useState<boolean | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    
    const checkKey = async () => {
      if (window.aistudio) {
        try {
          const selected = await window.aistudio.hasSelectedApiKey();
          setHasApiKey(selected);
        } catch (e) {
          console.error("Error checking API key:", e);
          setHasApiKey(false);
        }
      } else {
        // Fallback if utility is not available
        setHasApiKey(true);
      }
    };

    window.addEventListener('scroll', handleScroll);
    checkKey();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleOpenKeyDialog = async () => {
    if (window.aistudio) {
      try {
        await window.aistudio.openSelectKey();
        // Per guidelines, assume success immediately to prevent race conditions
        setHasApiKey(true);
      } catch (e) {
        console.error("Error opening key dialog:", e);
      }
    }
  };

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'glass-effect shadow-md py-3' : 'bg-transparent py-5'}`}>
      <div className="container mx-auto px-4 md:px-8 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="bg-blue-700 text-white p-2 rounded-lg">
            <i className="fas fa-city text-xl"></i>
          </div>
          <div>
            <span className={`text-xl font-bold block leading-none ${isScrolled ? 'text-blue-900' : 'text-white'}`}>AKBAR GROUPS</span>
            <span className={`text-[10px] uppercase tracking-widest ${isScrolled ? 'text-blue-600' : 'text-blue-200'}`}>Real Estate & Builders</span>
          </div>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-6 lg:gap-8">
          {NAV_ITEMS.map((item) => (
            <a
              key={item.label}
              href={item.href}
              className={`font-medium hover:text-blue-600 transition-colors ${isScrolled ? 'text-slate-700' : 'text-white'}`}
            >
              {item.label}
            </a>
          ))}
          
          <div className="flex items-center gap-3">
            {hasApiKey === false && (
              <button
                onClick={handleOpenKeyDialog}
                className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white px-5 py-2.5 rounded-full font-bold text-xs transition-all shadow-lg hover:shadow-amber-200 animate-pulse active:scale-95"
              >
                <i className="fas fa-sparkles"></i>
                Setup AI Assistant
              </button>
            )}
            {hasApiKey === true && isScrolled && (
              <div className="flex items-center gap-2 text-green-600 bg-green-50 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider">
                <i className="fas fa-circle-check"></i>
                AI Connected
              </div>
            )}
            <a
              href={BUSINESS_INFO.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-full font-semibold transition-all shadow-lg hover:shadow-blue-200"
            >
              Contact Now
            </a>
          </div>
        </div>

        {/* Mobile Toggle */}
        <button
          className="md:hidden text-2xl p-2"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <i className={`fas ${isMobileMenuOpen ? 'fa-times' : 'fa-bars'} ${isScrolled ? 'text-slate-900' : 'text-white'}`}></i>
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-white shadow-xl py-6 px-4 animate-in fade-in slide-in-from-top-4">
          <div className="flex flex-col gap-4">
            {hasApiKey === false && (
              <button
                onClick={handleOpenKeyDialog}
                className="bg-gradient-to-r from-amber-500 to-orange-600 text-white text-center py-3 rounded-lg font-bold flex items-center justify-center gap-2 shadow-md"
              >
                <i className="fas fa-key"></i>
                Initialize AI Support
              </button>
            )}
            {NAV_ITEMS.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="text-lg font-medium text-slate-800 border-b border-slate-100 pb-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {item.label}
              </a>
            ))}
            <a
              href={BUSINESS_INFO.whatsapp}
              className="bg-blue-600 text-white text-center py-3 rounded-lg font-bold"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Contact on WhatsApp
            </a>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
