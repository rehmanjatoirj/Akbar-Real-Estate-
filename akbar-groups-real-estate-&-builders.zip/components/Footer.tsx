
import React from 'react';
import { BUSINESS_INFO, NAV_ITEMS } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-white pt-20 pb-10">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2 mb-6">
              <div className="bg-blue-600 p-2 rounded-lg">
                <i className="fas fa-city text-xl text-white"></i>
              </div>
              <span className="text-2xl font-bold uppercase tracking-tighter">Akbar Groups</span>
            </div>
            <p className="text-slate-400 mb-8 leading-relaxed max-w-sm">
              The first and most trusted online real estate marketplace in Pakistan's twin cities. We bridge the gap between your dreams and the perfect property.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-blue-600 transition-colors">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-blue-400 transition-colors">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-pink-600 transition-colors">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-red-600 transition-colors">
                <i className="fab fa-youtube"></i>
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-8 relative inline-block">
              Quick Links
              <span className="absolute -bottom-2 left-0 w-8 h-1 bg-blue-600 rounded-full"></span>
            </h4>
            <ul className="space-y-4">
              {NAV_ITEMS.map((item) => (
                <li key={item.label}>
                  <a href={item.href} className="text-slate-400 hover:text-white hover:pl-2 transition-all duration-300">
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-8 relative inline-block">
              Our Services
              <span className="absolute -bottom-2 left-0 w-8 h-1 bg-blue-600 rounded-full"></span>
            </h4>
            <ul className="space-y-4 text-slate-400">
              <li className="hover:text-white transition-colors cursor-default">Property Buying & Selling</li>
              <li className="hover:text-white transition-colors cursor-default">Modern Construction</li>
              <li className="hover:text-white transition-colors cursor-default">Plot Investment Plans</li>
              <li className="hover:text-white transition-colors cursor-default">Real Estate Consultation</li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-8 relative inline-block">
              Contact Us
              <span className="absolute -bottom-2 left-0 w-8 h-1 bg-blue-600 rounded-full"></span>
            </h4>
            <ul className="space-y-6">
              <li className="flex gap-4">
                <div className="w-10 h-10 flex-shrink-0 rounded-xl bg-blue-600/10 flex items-center justify-center text-blue-500">
                  <i className="fas fa-map-marker-alt"></i>
                </div>
                <p className="text-sm text-slate-400">{BUSINESS_INFO.address}</p>
              </li>
              <li className="flex gap-4">
                <div className="w-10 h-10 flex-shrink-0 rounded-xl bg-blue-600/10 flex items-center justify-center text-blue-500">
                  <i className="fas fa-phone-alt"></i>
                </div>
                <p className="text-sm text-slate-400">{BUSINESS_INFO.phone}</p>
              </li>
              <li className="flex gap-4">
                <div className="w-10 h-10 flex-shrink-0 rounded-xl bg-blue-600/10 flex items-center justify-center text-blue-500">
                  <i className="fas fa-clock"></i>
                </div>
                <p className="text-sm text-slate-400 uppercase font-bold text-blue-400">Open 24 Hours</p>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-slate-500 text-sm">
          <p>© {new Date().getFullYear()} Akbar Groups Real Estate And Builders. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
