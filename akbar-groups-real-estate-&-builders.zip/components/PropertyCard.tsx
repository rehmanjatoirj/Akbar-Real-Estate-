
import React from 'react';
import { Property } from '../types';
import { BUSINESS_INFO } from '../constants';

interface Props {
  property: Property;
}

const PropertyCard: React.FC<Props> = ({ property }) => {
  return (
    <div className="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-slate-100 group">
      <div className="relative h-64 overflow-hidden">
        <img
          src={property.imageUrl}
          alt={property.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        {property.badge && (
          <div className="absolute top-4 left-4 bg-blue-600 text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-lg">
            {property.badge}
          </div>
        )}
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm text-blue-900 text-xs font-bold px-3 py-1.5 rounded-full shadow-md">
          {property.type}
        </div>
      </div>
      
      <div className="p-6">
        <div className="flex items-center gap-2 text-slate-500 text-sm mb-2">
          <i className="fas fa-location-dot"></i>
          <span>{property.location}</span>
        </div>
        
        <h3 className="text-xl font-bold text-slate-900 mb-3 group-hover:text-blue-700 transition-colors">
          {property.title}
        </h3>
        
        <div className="flex items-center justify-between pt-4 border-t border-slate-50">
          <div>
            <span className="text-xs text-slate-400 block uppercase font-semibold">Starting from</span>
            <span className="text-2xl font-extrabold text-blue-900">{property.price}</span>
          </div>
          <a
            href={`${BUSINESS_INFO.whatsapp}?text=Hi, I'm interested in ${property.title}`}
            target="_blank"
            rel="noopener noreferrer"
            className="w-12 h-12 flex items-center justify-center bg-slate-100 text-slate-600 rounded-2xl group-hover:bg-blue-600 group-hover:text-white transition-all shadow-sm"
          >
            <i className="fas fa-chevron-right"></i>
          </a>
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;
