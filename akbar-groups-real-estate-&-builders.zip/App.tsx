
import React, { useEffect, useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import PropertyCard from './components/PropertyCard';
import AIChatBot from './components/AIChatBot';
import Footer from './components/Footer';
import { PROPERTIES, BUSINESS_INFO } from './constants';

const App: React.FC = () => {
  const [showKeyWarning, setShowKeyWarning] = useState(false);

  useEffect(() => {
    const checkKey = async () => {
      if (window.aistudio) {
        try {
          const hasKey = await window.aistudio.hasSelectedApiKey();
          setShowKeyWarning(!hasKey);
        } catch (e) {
          setShowKeyWarning(true);
        }
      }
    };
    checkKey();
  }, []);

  const handleManualSetup = async () => {
    if (window.aistudio) {
      await window.aistudio.openSelectKey();
      setShowKeyWarning(false);
    }
  };

  return (
    <div className="min-h-screen">
      <Navbar />
      
      {showKeyWarning && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[60] w-full max-w-lg px-4">
          <div className="bg-white/90 backdrop-blur-md border border-amber-200 p-5 rounded-3xl shadow-2xl flex items-center gap-4 animate-in slide-in-from-top-4 duration-500">
            <div className="bg-amber-100 text-amber-600 w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0">
              <i className="fas fa-wand-magic-sparkles text-xl"></i>
            </div>
            <div className="flex-1">
              <p className="text-slate-900 text-sm font-bold leading-tight">AI Assistant is ready!</p>
              <p className="text-slate-500 text-xs mt-1">To enable property search and assistance, please connect your project.</p>
              <button 
                onClick={handleManualSetup}
                className="mt-2 text-blue-600 text-xs font-bold hover:underline flex items-center gap-1"
              >
                Connect Now <i className="fas fa-chevron-right text-[10px]"></i>
              </button>
            </div>
            <button 
              onClick={() => setShowKeyWarning(false)}
              className="text-slate-300 hover:text-slate-500 p-2"
            >
              <i className="fas fa-times"></i>
            </button>
          </div>
        </div>
      )}

      <main>
        <Hero />

        {/* Features Section */}
        <section id="about" className="py-24 bg-white overflow-hidden">
          <div className="container mx-auto px-4 md:px-8">
            <div className="flex flex-col lg:flex-row items-center gap-16">
              <div className="lg:w-1/2 relative">
                <div className="absolute -top-10 -left-10 w-40 h-40 bg-blue-50 rounded-full z-0"></div>
                <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-blue-50 rounded-full z-0"></div>
                <img
                  src="https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&q=80&w=800"
                  alt="About Us"
                  className="rounded-3xl shadow-2xl relative z-10 w-full object-cover aspect-[4/5]"
                />
                <div className="absolute bottom-10 -left-10 bg-white p-6 rounded-2xl shadow-xl z-20 hidden md:block border border-slate-100">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white text-xl">
                      <i className="fas fa-award"></i>
                    </div>
                    <div>
                      <h4 className="font-extrabold text-slate-900 leading-none">10+ Years</h4>
                      <p className="text-xs text-slate-500 uppercase tracking-widest mt-1">Experience</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="lg:w-1/2">
                <div className="inline-block px-4 py-1.5 bg-blue-100 text-blue-700 rounded-full text-xs font-bold uppercase tracking-widest mb-6">
                  About Akbar Groups
                </div>
                <h2 className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-8 leading-tight">
                  Pakistan's 1st <span className="text-blue-600 underline decoration-blue-200 underline-offset-8">Online Marketplace</span> for Real Estate
                </h2>
                <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                  We are the best property dealers in Pakistan's twin cities, Rawalpindi and Islamabad. With over a decade of experience, we don't just sell plots; we build futures.
                </p>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-10">
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
                      <i className="fas fa-check"></i>
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900">Buying & Selling</h4>
                      <p className="text-sm text-slate-500">Hassle-free transfers and fair pricing.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
                      <i className="fas fa-check"></i>
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900">Expert Guidance</h4>
                      <p className="text-sm text-slate-500">Data-backed investment advice.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
                      <i className="fas fa-check"></i>
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900">Construction</h4>
                      <p className="text-sm text-slate-500">Premium quality and modern designs.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
                      <i className="fas fa-check"></i>
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900">Plot Installments</h4>
                      <p className="text-sm text-slate-500">Flexible 1-5 year payment plans.</p>
                    </div>
                  </div>
                </div>
                
                <a href="#contact" className="inline-flex items-center gap-3 font-bold text-blue-700 group">
                  Learn more about our services
                  <i className="fas fa-arrow-right group-hover:translate-x-2 transition-transform"></i>
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* Properties Grid */}
        <section id="properties" className="py-24 bg-slate-50">
          <div className="container mx-auto px-4 md:px-8">
            <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
              <div className="max-w-xl">
                <div className="inline-block px-4 py-1.5 bg-blue-100 text-blue-700 rounded-full text-xs font-bold uppercase tracking-widest mb-4">
                  Exclusive Deals
                </div>
                <h2 className="text-4xl font-extrabold text-slate-900">Current Top Projects</h2>
                <p className="text-slate-500 mt-4">Discover the best investment opportunities in Rawalpindi and Islamabad's premier societies.</p>
              </div>
              <button className="bg-white text-slate-900 border border-slate-200 px-6 py-3 rounded-2xl font-bold hover:bg-slate-50 transition-colors">
                View All Listings
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {PROPERTIES.map(property => (
                <PropertyCard key={property.id} property={property} />
              ))}
            </div>
          </div>
        </section>

        {/* Reviews Section */}
        <section id="reviews" className="py-24 bg-white overflow-hidden relative">
          <div className="container mx-auto px-4 md:px-8 relative z-10">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <h2 className="text-4xl font-extrabold text-slate-900 mb-6">What Our Clients Say</h2>
              <div className="flex items-center justify-center gap-1 text-yellow-400 text-xl mb-4">
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
              </div>
              <p className="text-slate-600 text-lg">
                Rated <span className="font-extrabold text-slate-900">{BUSINESS_INFO.rating}.0</span> based on <span className="font-extrabold text-slate-900">{BUSINESS_INFO.reviewsCount}</span> genuine Google reviews.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-slate-50 p-8 rounded-3xl border border-slate-100">
                  <div className="flex items-center gap-1 text-yellow-400 text-sm mb-6">
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                  </div>
                  <p className="italic text-slate-700 mb-8 leading-relaxed">
                    "Akbar Groups provided me with an excellent installment plan for New Metro City. Their process is transparent and highly professional. Best in Bahria Town!"
                  </p>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center font-bold text-blue-700">
                      U{i}
                    </div>
                    <div>
                      <h5 className="font-bold text-slate-900">Satisfied Client</h5>
                      <p className="text-xs text-slate-400">Verified Buyer</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-16 text-center">
              <a 
                href="https://www.google.com/search?q=Akbar+Groups+Real+Estate+And+Builders" 
                target="_blank" 
                className="inline-flex items-center gap-2 bg-blue-600 text-white px-8 py-4 rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-xl shadow-blue-200"
              >
                Read All Reviews on Google
              </a>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-24 bg-blue-900 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-1/3 h-full bg-blue-800 skew-x-12 translate-x-1/2 opacity-20"></div>
          
          <div className="container mx-auto px-4 md:px-8 relative z-10">
            <div className="bg-white rounded-[40px] shadow-2xl overflow-hidden flex flex-col lg:flex-row">
              <div className="lg:w-1/2 p-8 md:p-16">
                <h2 className="text-4xl font-extrabold text-slate-900 mb-8">Get In Touch</h2>
                <p className="text-slate-500 mb-12">Have questions about a project? Our real estate experts are available 24/7 to assist you.</p>
                
                <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-2">Full Name</label>
                      <input type="text" className="w-full bg-slate-50 border-none rounded-2xl px-6 py-4 focus:ring-2 focus:ring-blue-600 transition-all" placeholder="John Doe" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-2">Phone Number</label>
                      <input type="tel" className="w-full bg-slate-50 border-none rounded-2xl px-6 py-4 focus:ring-2 focus:ring-blue-600 transition-all" placeholder="03XX XXXXXXX" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">Project Interested In</label>
                    <select className="w-full bg-slate-50 border-none rounded-2xl px-6 py-4 focus:ring-2 focus:ring-blue-600 transition-all">
                      <option>New Metro City Gujar Khan</option>
                      <option>Kingdom Valley Islamabad</option>
                      <option>Park View City</option>
                      <option>Bahria Town Projects</option>
                      <option>Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">Message</label>
                    <textarea className="w-full bg-slate-50 border-none rounded-2xl px-6 py-4 h-32 focus:ring-2 focus:ring-blue-600 transition-all" placeholder="Tell us how we can help..."></textarea>
                  </div>
                  <button className="w-full bg-blue-600 text-white py-5 rounded-2xl font-bold text-lg hover:bg-blue-700 transition-all shadow-xl shadow-blue-100 flex items-center justify-center gap-3">
                    Send Inquiry
                    <i className="fas fa-paper-plane"></i>
                  </button>
                </form>
              </div>
              
              <div className="lg:w-1/2 bg-slate-50 p-8 md:p-16">
                <div className="h-full flex flex-col">
                  <h3 className="text-2xl font-extrabold text-slate-900 mb-8">Direct Contact</h3>
                  <div className="space-y-8 flex-grow">
                    <div className="flex gap-6">
                      <div className="w-14 h-14 bg-white rounded-2xl shadow-sm flex items-center justify-center text-blue-600 text-xl flex-shrink-0">
                        <i className="fas fa-phone"></i>
                      </div>
                      <div>
                        <p className="text-xs text-slate-400 uppercase tracking-widest font-bold mb-1">Call Us 24/7</p>
                        <p className="text-xl font-extrabold text-slate-900">{BUSINESS_INFO.phone}</p>
                      </div>
                    </div>
                    <div className="flex gap-6">
                      <div className="w-14 h-14 bg-white rounded-2xl shadow-sm flex items-center justify-center text-blue-600 text-xl flex-shrink-0">
                        <i className="fab fa-whatsapp"></i>
                      </div>
                      <div>
                        <p className="text-xs text-slate-400 uppercase tracking-widest font-bold mb-1">WhatsApp Chat</p>
                        <a href={BUSINESS_INFO.whatsapp} target="_blank" className="text-xl font-extrabold text-blue-600 hover:underline">Instant Support</a>
                      </div>
                    </div>
                    <div className="flex gap-6">
                      <div className="w-14 h-14 bg-white rounded-2xl shadow-sm flex items-center justify-center text-blue-600 text-xl flex-shrink-0">
                        <i className="fas fa-map-marker-alt"></i>
                      </div>
                      <div>
                        <p className="text-xs text-slate-400 uppercase tracking-widest font-bold mb-1">Visit Office</p>
                        <p className="text-slate-700 leading-relaxed font-semibold">{BUSINESS_INFO.address}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-12 rounded-3xl overflow-hidden h-64 shadow-inner relative border-4 border-white">
                    <iframe 
                      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3326.697472097893!2d73.0858!3d33.5204!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzPCsDMxJzEzLjQiTiA3M8KwMDUnMDguOSJF!5e0!3m2!1sen!2s!4v1620000000000!5m2!1sen!2s" 
                      className="w-full h-full border-none grayscale"
                      allowFullScreen={true} 
                      loading="lazy"
                    ></iframe>
                    <div className="absolute inset-0 pointer-events-none ring-1 ring-inset ring-black/5"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
      <AIChatBot />
    </div>
  );
};

export default App;
