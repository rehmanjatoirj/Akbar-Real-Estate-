
import { GoogleGenAI } from "@google/genai";
import { PROPERTIES, BUSINESS_INFO } from "./constants";

export async function getPropertyAssistance(userMessage: string) {
  // Ensure we have an API key from the environment
  const apiKey = process.env.API_KEY;

  if (!apiKey) {
    if (window.aistudio) {
      await window.aistudio.openSelectKey();
    }
    return "Please set up your AI connection using the button in the header to continue.";
  }

  try {
    // Fresh instance for every call
    const ai = new GoogleGenAI({ apiKey: apiKey });
    
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userMessage,
      config: {
        systemInstruction: `You are a professional real estate assistant for Akbar Groups Real Estate And Builders. 
        Our office is in Bahria Town Phase 4, Islamabad. We have ${BUSINESS_INFO.experience} of experience.
        Our current top listings are: ${PROPERTIES.map(p => `${p.title} at ${p.price} in ${p.location}`).join(', ')}.
        Be polite, professional, and encourage users to contact us at ${BUSINESS_INFO.phone} or visit our office.
        If they ask for specific prices, use the data provided. If you don't know, suggest they call our experts.
        Focus on Bahria Town, New Metro City, and Kingdom Valley projects.
        IMPORTANT: If you detect the user is having technical issues with the connection, kindly suggest they refresh the page or click the 'Setup AI' button in the header.`
      }
    });
    return response.text;
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    
    // Handle "refused to connect" or "not found" which implies a missing or invalid project
    if (error.message?.includes("Requested entity was not found") || error.message?.includes("refused")) {
      if (window.aistudio) {
        await window.aistudio.openSelectKey();
      }
      return "The connection to the AI service was refused. I've re-opened the project selection tool for you. Please select a paid project to enable the assistant.";
    }
    
    return "I'm having a temporary connection issue. Please try again in a moment or reach out to us at " + BUSINESS_INFO.phone;
  }
}
