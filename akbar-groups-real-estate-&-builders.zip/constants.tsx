
import { Property, NavItem } from './types';

export const NAV_ITEMS: NavItem[] = [
  { label: 'Home', href: '#home' },
  { label: 'Properties', href: '#properties' },
  { label: 'About Us', href: '#about' },
  { label: 'Reviews', href: '#reviews' },
  { label: 'Contact', href: '#contact' },
];

export const PROPERTIES: Property[] = [
  {
    id: '1',
    title: 'New Metro City Gujar Khan Plot',
    price: 'Rs 450,000',
    location: 'Gujar Khan',
    type: 'Plot',
    size: '5 Marla',
    imageUrl: 'https://picsum.photos/seed/property1/800/600',
    badge: 'Easy Installments'
  },
  {
    id: '2',
    title: 'Rudn Enclave Rawalpindi Residential',
    price: 'Rs 360,000',
    location: 'Rawalpindi',
    type: 'Residential',
    size: '7 Marla',
    imageUrl: 'https://picsum.photos/seed/property2/800/600',
    badge: 'Best Seller'
  },
  {
    id: '3',
    title: 'Park View City Overseas Block',
    price: 'Rs 2,750,000',
    location: 'Islamabad',
    type: 'Plot',
    size: '10 Marla',
    imageUrl: 'https://picsum.photos/seed/property3/800/600',
    badge: 'Premium'
  },
  {
    id: '4',
    title: 'Kingdom Valley Discount Offer',
    price: 'Rs 20,000',
    location: 'Islamabad',
    type: 'Plot',
    size: '5 Marla',
    imageUrl: 'https://picsum.photos/seed/property4/800/600',
    badge: 'Limited Offer'
  },
  {
    id: '5',
    title: 'Mivida Islamabad Pakistan Plot',
    price: 'Rs 750,000',
    location: 'Islamabad',
    type: 'Plot',
    size: '5.5 Marla',
    imageUrl: 'https://picsum.photos/seed/property5/800/600'
  },
  {
    id: '6',
    title: 'Kingdom Valley Commercial',
    price: 'Rs 650,000',
    location: 'Islamabad',
    type: 'Commercial',
    size: '4 Marla',
    imageUrl: 'https://picsum.photos/seed/property6/800/600',
    badge: 'Commercial'
  },
  {
    id: '7',
    title: 'Park View City Overseas 5 Marla',
    price: 'Rs 1,625,000',
    location: 'Islamabad',
    type: 'Plot',
    size: '5 Marla',
    imageUrl: 'https://picsum.photos/seed/property7/800/600'
  },
  {
    id: '8',
    title: 'Bahria Town Peshawar Plots',
    price: 'Call for Price',
    location: 'Peshawar',
    type: 'Plot',
    size: 'Various',
    imageUrl: 'https://picsum.photos/seed/property8/800/600',
    badge: 'Coming Soon'
  }
];

export const BUSINESS_INFO = {
  name: "Akbar Groups Real Estate And Builders",
  phone: "0333 6955557",
  whatsapp: "https://wa.me/923336955557",
  address: "3rd Floor Plot 181, Office : 9, Main Blvd, Phase 4 Civic Center Bahria Town, Islamabad, 46000",
  email: "info@akbargroups.com",
  experience: "10+ Years",
  rating: 5.0,
  reviewsCount: 86
};
