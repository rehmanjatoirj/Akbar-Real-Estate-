
export interface Property {
  id: string;
  title: string;
  price: string;
  location: string;
  type: 'Residential' | 'Commercial' | 'Plot';
  size: string;
  imageUrl: string;
  badge?: string;
}

export interface NavItem {
  label: string;
  href: string;
}

export interface Review {
  author: string;
  rating: number;
  comment: string;
  date: string;
}
